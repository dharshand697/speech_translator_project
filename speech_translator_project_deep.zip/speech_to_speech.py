import speech_recognition as sr
from deep_translator import GoogleTranslator
import pyttsx3
import time
import sqlite3

def init_tts():
    engine = pyttsx3.init()
    engine.setProperty('rate', 150)
    return engine

def speak_text(engine, text):
    engine.say(text)
    engine.runAndWait()

def log_translation(src_lang, tgt_lang, source_text, translated_text):
    try:
        conn = sqlite3.connect("translations.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO translations (source_lang, target_lang, source_text, translated_text) VALUES (?, ?, ?, ?)", 
                       (src_lang, tgt_lang, source_text, translated_text))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Failed to log translation:", e)

def main():
    print("=== Simple Speech-to-Speech Translator (Deep Translator Version) ===")
    print("You need a microphone and Internet (for recognition + translation).")
    print("Supported language codes: en (English), hi (Hindi), es (Spanish), fr (French), de (German), etc.")
    print("Type 'exit' as source language to quit.\n")

    src_lang = input("Enter SOURCE language code (e.g. en): ").strip() or "en"
    if src_lang.lower() == "exit":
        print("Exiting.")
        return
    tgt_lang = input("Enter TARGET language code (e.g. hi): ").strip() or "hi"

    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    tts_engine = init_tts()

    print("\nAdjusting for ambient noise, please be silent for 1 second...")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=1)
    print("Ready! Speak now (say 'stop' to end).")

    while True:
        try:
            with mic as source:
                print("\nListening...")
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=8)
            print("Recognizing...")
            try:
                recognized = recognizer.recognize_google(audio, language=src_lang)
            except sr.UnknownValueError:
                print("Could not understand audio.")
                continue
            except sr.RequestError as e:
                print("Could not request results from Google Speech Recognition service; {0}".format(e))
                continue

            recognized = recognized.strip()
            print(f"Source [{src_lang}]: {recognized}")

            if recognized.lower() in ("stop", "exit", "quit"):
                print("Stopping translator.")
                break

            # Translate using deep-translator
            try:
                translated = GoogleTranslator(source=src_lang, target=tgt_lang).translate(recognized)
            except Exception as e:
                print("Translation failed:", e)
                translated = "[translation error]"

            print(f"Translated [{tgt_lang}]: {translated}")

            # Log to database
            log_translation(src_lang, tgt_lang, recognized, translated)

            # Speak the translated text (TTS)
            speak_text(tts_engine, translated)

        except sr.WaitTimeoutError:
            print("Listening timed out, trying again...")
            continue
        except KeyboardInterrupt:
            print("\nUser interrupted. Exiting.")
            break
        except Exception as e:
            print("Unexpected error:", e)
            time.sleep(1)
            continue

    try:
        tts_engine.stop()
    except Exception:
        pass

if __name__ == "__main__":
    main()
